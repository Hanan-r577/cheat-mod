==============================================================================
  AphidZ — ONE FILE  (version.dll)
==============================================================================

This is the entire thing in a single DLL. No second DLL, no AphidZ.dll, no
dllinject.txt, no emulator, no Python, no server, no port 443, no admin, no
PowerShell, no hosts file, no cert, no injector. Menu shows: hawkisprolmfao55

SETUP (Windows)
  1. Open the PixelWorlds game folder (the one with PixelWorlds.exe).
     Steam: right-click PixelWorlds -> Manage -> Browse local files.
  2. Copy  version.dll  into that folder (next to PixelWorlds.exe).
  3. Launch PixelWorlds normally. (Optional: add -force-d3d11 in Steam.)
  4. In AphidZ: type ANY key -> Login. Done.

SETUP (Linux / Steam Proton)
  Same: put version.dll next to the game exe, then set Steam Launch Options:
     WINEDLLOVERRIDES="version=n,b" %command% -force-d3d11
  Launch from Steam.

That is the whole process. One file. Nothing to run.

WHAT IT DOES
  Windows/Wine auto-loads an app-local version.dll at game start. This one:
   - forwards all real version.* calls so the game is unaffected
   - hooks WinHTTP and answers AphidZ's 3 license endpoints IN-PROCESS from
     baked-in captured data (leases set to now+1h, success) — no network,
     so no server / port / cert / hosts / concurrency limit / expiry
   - unpacks the embedded clean AphidZ, loads it, and patches its
     runtime_core check in memory so it accepts the response
  Debug log: %TEMP%\aphidz_aio.log

IF THE GAME WON'T START / NOTHING LOADS
  Some setups don't auto-load an app-local version.dll. Then this file must
  be injected instead (any injector): inject version.dll into PixelWorlds
  after launch. It still does everything itself once loaded.

UNINSTALL
  Delete version.dll from the game folder (and clear the WINEDLLOVERRIDES
  launch option on Linux). A transient %TEMP%\aphidz_core.dll may remain;
  it is harmless and can be deleted.

  For owner/recovery use of software you have rights to.
==============================================================================
