==============================================================================
  AphidZ — Friend Build  (NO Python, NO server, NO port 443, NO admin,
                           NO PowerShell, NO hosts file, NO cert)
  Menu shows: hawkisprolmfao55
==============================================================================

This build answers AphidZ's license server ENTIRELY inside the game process.
There is no emulator, no Python, nothing listening on a port, no hosts edit,
no certificate, no scripts. All the things that failed on your machine are
gone. You just put 4 files in the game folder and launch.

CONTENTS
--------
  version.dll        Auto-loader. Windows/Wine loads an app-local version.dll
                     at game start; it then loads the two below (and forwards
                     real version.* calls so the game is unaffected).
  AphidZBypass.dll   Hooks WinHTTP in-process and answers the 3 auth
                     endpoints from baked-in captured data (no network), and
                     auto-patches AphidZ's runtime_core check in memory.
  AphidZ.dll         Clean AphidZ (gets patched in memory by AphidZBypass).
  dllinject.txt      Load order (AphidZBypass first, 2s, then AphidZ).
  AphidZInjector.exe Fallback injector (only if the auto-load doesn't work).

==============================================================================
SETUP  (Windows — the easy path, no tools)
==============================================================================
  1. Find the PixelWorlds game folder (the one with PixelWorlds.exe).
     Steam: right-click PixelWorlds -> Manage -> Browse local files.
  2. Copy ALL of these into that folder (next to PixelWorlds.exe):
        version.dll
        AphidZBypass.dll
        AphidZ.dll
        dllinject.txt
  3. Launch PixelWorlds normally (Steam Play / the .exe). For best results
     add  -force-d3d11  to Steam launch options (not strictly required).
  4. In the AphidZ login: type ANY key -> Login. Done. Menu shows
     "hawkisprolmfao55". Fly / features work.

  That's it. No admin, no PowerShell, no Python, nothing to run.

  Debug log if needed:  %TEMP%\aphidz_bypass.log

==============================================================================
SETUP  (Linux / Steam Proton)
==============================================================================
  Same 4 files into the game's exe folder, then set Steam Launch Options:
        WINEDLLOVERRIDES="version=n,b" %command% -force-d3d11
  Launch from Steam. Same result.

==============================================================================
IF NOTHING LOADS  (rare — game didn't pull in version.dll)
==============================================================================
  Use the fallback injector instead (still no Python/server/admin):
    1. Launch PixelWorlds.
    2. Open a normal cmd in the game folder and run:
         AphidZInjector.exe --dll AphidZBypass.dll
       wait 3 seconds, then:
         AphidZInjector.exe --dll AphidZ.dll
    3. Login with any key.
  (You can delete version.dll + dllinject.txt if you use this path.)

==============================================================================
TROUBLESHOOTING
==============================================================================
  Game won't start after copying files
    - Remove version.dll, relaunch to confirm it's the cause; if so the
      game treats version.dll specially — use the injector fallback above.

  AphidZ menu never appears
    - AphidZ.dll didn't load. Check %TEMP%\aphidz_bypass.log exists (means
      AphidZBypass ran). Try the injector fallback.

  Login still says "Runtime core invalid"
    - The memory patch didn't hit. Make sure AphidZ.dll from THIS folder is
      the one used (don't mix with an old patched copy). Check the log.

  Login says "cannot reach server" / hangs
    - Shouldn't happen (no network). Means AphidZBypass loaded AFTER AphidZ
      tried to auth. Use the injector fallback and inject AphidZBypass.dll
      FIRST, wait 3s, then AphidZ.dll.

UNINSTALL
  Delete the 4 files from the game folder. (Clear the WINEDLLOVERRIDES
  launch option on Linux.)

HOW IT WORKS (short)
  version.dll loads AphidZBypass.dll at game start. AphidZBypass MinHooks
  WinHTTP; when AphidZ POSTs to api-rejoin.pebletz.xyz it never goes to the
  network — the hook returns the captured valid JSON with leases rewritten
  to "now + 1h" and success=true, so the session never expires and there's
  no concurrency limit. It also finds the AphidZ module and flips the 3-byte
  runtime_core validity check so the lease-rewritten response is accepted.
  Pure in-process: nothing to install, nothing to run, nothing to break.

  For owner/recovery use of software you have rights to.
==============================================================================
